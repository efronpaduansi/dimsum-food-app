<?php

$conn = mysqli_connect("localhost", "root", "", "dimsum_pawonkulo");

if(mysqli_connect_errno()){
    echo "Gagal terhubung ke database" .die();
}


?>